import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import settingImage from "../assets/setting.png";

function Processing() {
    const navigate = useNavigate();
    const location = useLocation();
    const pageName = location.state?.pageName || "GeneratedPage";

    useEffect(() => {
        const redirectTimeout = setTimeout(() => {
            navigate("/generated", {
                state: {
                    pageName,
                },
            });
        }, 5000);
        return () => {
            clearTimeout(redirectTimeout);
        };
    }, [navigate, pageName]);
    return (
        <div
            style={{
                maxWidth: "1200px",
                minHeight: "100vh",
                margin: "0 auto",
                display: "flex",
                flexDirection: "column",
            }}
        >
            <div
                style={{
                    flex: 1,
                    padding: "60px 40px",
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                }}
            >
                <img 
                    src={settingImage}
                    alt="file"
                    style={{
                        height: "36px",
                        marginBottom: "2px",
                        animation: "spin 3s linear infinite",
                    }}
                />
                <h4
                    style={{
                        fontSize: "20px",
                        marginBottom: "8px",
                        marginLeft: "2px",
                    }}
                >
                    Processing
                </h4>
            </div>
        </div>
    );

}

export default Processing;
